// ===== HYPER M SHOP - ANIME BACKGROUND ENGINE (MOBILE & PERFORMANCE OPTIMIZED) =====
(function() {
  const canvas = document.getElementById('anime-bg');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');

  // Check if we are on a mobile device
  const isMobile = (window.innerWidth <= 768 || /Mobi|Android|iPhone|iPad/i.test(navigator.userAgent));

  // Resize canvas to full window
  function resize() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
  }
  resize();
  window.addEventListener('resize', resize);

  // ===== PARTICLES (Reduced on mobile for performance) =====
  const PARTICLE_COUNT = isMobile ? 35 : 120;
  const particles = [];

  class Particle {
    constructor() { this.reset(true); }
    reset(init) {
      this.x = Math.random() * canvas.width;
      this.y = init ? Math.random() * canvas.height : -10;
      this.size = Math.random() * 3 + 0.5;
      this.speedY = Math.random() * 1.5 + 0.3;
      this.speedX = (Math.random() - 0.5) * 0.6;
      this.opacity = Math.random() * 0.7 + 0.2;
      this.type = Math.floor(Math.random() * 3); // 0=circle, 1=sakura, 2=spark
      this.color = this.getColor();
      this.angle = Math.random() * Math.PI * 2;
      this.rotSpeed = (Math.random() - 0.5) * 0.05;
      this.life = 1;
      this.decay = Math.random() * 0.003 + 0.001;
    }
    getColor() {
      const colors = [
        `255,0,51`,    // Red
        `255,80,120`,  // Pink-red
        `255,200,200`, // Light pink (sakura)
        `255,255,255`, // White
        `200,0,30`,    // Dark red
      ];
      return colors[Math.floor(Math.random() * colors.length)];
    }
    update() {
      this.y += this.speedY;
      this.x += this.speedX;
      this.angle += this.rotSpeed;
      this.life -= this.decay;
      if (this.y > canvas.height + 20 || this.life <= 0) this.reset(false);
    }
    draw() {
      ctx.save();
      ctx.globalAlpha = this.opacity * this.life;
      ctx.translate(this.x, this.y);
      ctx.rotate(this.angle);

      if (this.type === 0) {
        // Glowing circle
        if (!isMobile) {
          const g = ctx.createRadialGradient(0,0,0, 0,0, this.size*4);
          g.addColorStop(0, `rgba(${this.color},0.9)`);
          g.addColorStop(1, `rgba(${this.color},0)`);
          ctx.fillStyle = g;
          ctx.beginPath();
          ctx.arc(0, 0, this.size * 4, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.fillStyle = `rgba(${this.color},1)`;
        ctx.beginPath();
        ctx.arc(0, 0, this.size, 0, Math.PI * 2);
        ctx.fill();

      } else if (this.type === 1) {
        // Sakura petal shape
        ctx.fillStyle = `rgba(${this.color},0.85)`;
        ctx.beginPath();
        for (let i = 0; i < 5; i++) {
          const a = (i / 5) * Math.PI * 2;
          const r = this.size * 3;
          const r2 = this.size * 1.2;
          const x1 = Math.cos(a) * r;
          const y1 = Math.sin(a) * r;
          const x2 = Math.cos(a + Math.PI/5) * r2;
          const y2 = Math.sin(a + Math.PI/5) * r2;
          if (i === 0) ctx.moveTo(x1, y1);
          else ctx.lineTo(x1, y1);
          ctx.lineTo(x2, y2);
        }
        ctx.closePath();
        ctx.fill();

      } else {
        // Spark/diamond
        ctx.fillStyle = `rgba(${this.color},0.9)`;
        const s = this.size * 2.5;
        ctx.beginPath();
        ctx.moveTo(0, -s);
        ctx.lineTo(s*0.4, 0);
        ctx.lineTo(0, s);
        ctx.lineTo(-s*0.4, 0);
        ctx.closePath();
        ctx.fill();
        
        // Skip canvas shadow blur on mobile to prevent graphics lag
        if (!isMobile) {
          ctx.shadowColor = `rgba(${this.color},0.8)`;
          ctx.shadowBlur = 10;
          ctx.fill();
        }
      }
      ctx.restore();
    }
  }

  for (let i = 0; i < PARTICLE_COUNT; i++) {
    particles.push(new Particle());
  }

  // ===== ENERGY BEAMS / LIGHTNING LINES (Reduced on mobile) =====
  const beams = [];
  const BEAM_COUNT = isMobile ? 3 : 8;

  class Beam {
    constructor() { this.reset(); }
    reset() {
      this.x = Math.random() * canvas.width;
      this.y = 0;
      this.width = Math.random() * 1.5 + 0.2;
      this.speed = Math.random() * 3 + 1;
      this.opacity = Math.random() * 0.25 + 0.05;
      this.length = Math.random() * 200 + 80;
      this.angle = Math.PI/2 + (Math.random()-0.5)*0.5;
      this.color = Math.random() > 0.4 ? '255,0,51' : '255,255,255';
      this.trail = [];
    }
    update() {
      this.trail.push({x: this.x, y: this.y});
      if (this.trail.length > 20) this.trail.shift();
      this.x += Math.cos(this.angle) * this.speed;
      this.y += Math.sin(this.angle) * this.speed;
      if (this.y > canvas.height + 50) this.reset();
    }
    draw() {
      if (this.trail.length < 2) return;
      ctx.save();
      ctx.strokeStyle = `rgba(${this.color},${this.opacity})`;
      ctx.lineWidth = this.width;
      ctx.lineCap = 'round';
      if (!isMobile) {
        ctx.shadowColor = `rgba(${this.color},0.5)`;
        ctx.shadowBlur = 8;
      }
      ctx.beginPath();
      ctx.moveTo(this.trail[0].x, this.trail[0].y);
      for (let i = 1; i < this.trail.length; i++) {
        ctx.lineTo(this.trail[i].x, this.trail[i].y);
      }
      ctx.stroke();
      ctx.restore();
    }
  }

  for (let i = 0; i < BEAM_COUNT; i++) {
    const b = new Beam();
    b.y = Math.random() * canvas.height;
    beams.push(b);
  }

  // ===== WAVE RINGS (Reduced on mobile) =====
  const rings = [];
  const RING_COUNT = isMobile ? 2 : 6;
  
  class Ring {
    constructor() { this.reset(true); }
    reset(init) {
      this.x = Math.random() * canvas.width;
      this.y = Math.random() * canvas.height;
      this.r = init ? Math.random() * 200 : 0;
      this.maxR = Math.random() * 250 + 100;
      this.speed = Math.random() * 1.5 + 0.5;
      this.opacity = Math.random() * 0.15 + 0.03;
      this.color = Math.random() > 0.5 ? '255,0,51' : '255,50,80';
      this.width = Math.random() * 1.5 + 0.5;
    }
    update() {
      this.r += this.speed;
      if (this.r > this.maxR) this.reset(false);
    }
    draw() {
      const fade = 1 - this.r / this.maxR;
      ctx.save();
      ctx.strokeStyle = `rgba(${this.color},${this.opacity * fade})`;
      ctx.lineWidth = this.width;
      if (!isMobile) {
        ctx.shadowColor = `rgba(${this.color},0.3)`;
        ctx.shadowBlur = 6;
      }
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.r, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }
  }

  for (let i = 0; i < RING_COUNT; i++) rings.push(new Ring());

  // ===== GRID SCAN LINES =====
  let scanY = 0;

  // ===== MAIN ANIME CHARACTER SILHOUETTE (shader style) =====
  function drawAnimeGlow(t) {
    if (isMobile) return; // Disable heavy gradient filters on mobile to improve rendering FPS
    const cx = canvas.width / 2;
    const cy = canvas.height / 2;
    const pulse = Math.sin(t * 0.001) * 0.5 + 0.5;

    const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, 400 + pulse * 100);
    g.addColorStop(0, `rgba(255,0,51,${0.07 + pulse * 0.05})`);
    g.addColorStop(0.5, `rgba(180,0,30,${0.03 + pulse * 0.02})`);
    g.addColorStop(1, `rgba(0,0,0,0)`);
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  }

  // ===== MAIN LOOP =====
  let t = 0;
  function animate() {
    requestAnimationFrame(animate);
    t++;

    // Clear
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw base dark background
    ctx.fillStyle = 'rgba(10,10,15,0.35)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Central anime glow (Desktop only)
    drawAnimeGlow(t);

    // Rings
    rings.forEach(r => { r.update(); r.draw(); });

    // Beams
    beams.forEach(b => { b.update(); b.draw(); });

    // Horizontal scan line
    scanY = (scanY + 0.8) % canvas.height;
    const scanGrad = ctx.createLinearGradient(0, scanY-40, 0, scanY+40);
    scanGrad.addColorStop(0, 'rgba(255,0,51,0)');
    scanGrad.addColorStop(0.5, 'rgba(255,0,51,0.04)');
    scanGrad.addColorStop(1, 'rgba(255,0,51,0)');
    ctx.fillStyle = scanGrad;
    ctx.fillRect(0, scanY - 40, canvas.width, 80);

    // Particles (on top)
    particles.forEach(p => { p.update(); p.draw(); });
  }

  animate();
})();
